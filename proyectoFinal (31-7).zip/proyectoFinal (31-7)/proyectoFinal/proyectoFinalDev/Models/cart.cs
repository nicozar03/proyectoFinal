/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using Dapper;
namespace proyectoFinalDev.Models
{
    public static class Cart
    {
        private int _idProducto;
        private float _precio;
        private float _nombre;
        private float _foto;

         public int idProducto {
            get { return _idProducto;}
            set{
                _idProducto= value;
            }
        }

        public float precio {
            get { return _precio;}
            set{
                _precio = value;
            }
        }

                public string nombre {
            get { return _nombre;}
            set{
                _nombre = value;
            }
        }

                public string foto {
            get { return _foto;}
            set{
                _foto = value;
            }
        }

                public Cart(){
            
        }

    }
}*/